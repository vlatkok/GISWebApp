﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using ESRI.ArcGIS.Client;
using ESRI.ArcGIS.Client.Toolkit;
using ESRI.ArcGIS.Client.Geometry;
using ESRI.ArcGIS.Client.Projection;



namespace Editing
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            
            Editor myEditor = LayoutRoot.Resources["MyEditor"] as Editor;
            myEditor.LayerIDs = new string[1] { "Podloga" }; //"Transport"

            MyEditorWidget.LayerIDs = new string[6] { "Podloga", "IndustrijaPol", "Mostovi", "Transport", "TransportPol","Ulica" };
          

          }


        private void FeatureLayer_MouseLeftButtonUp(object sender, GraphicMouseButtonEventArgs args)
        {
            FeatureLayer featureLayer = sender as FeatureLayer;
            for (int i = 0; i < featureLayer.SelectionCount; i++)
                featureLayer.SelectedGraphics.ToList()[i].UnSelect();
            args.Graphic.Select();

            MyFeatureDataForm.FeatureLayer = featureLayer;
            MyFeatureDataForm.GraphicSource = args.Graphic;
            FeatureDataFormBorder.Visibility = System.Windows.Visibility.Visible;
            foreach (var g in featureLayer.SelectedGraphics.ToArray()) { g.Selected = g == args.Graphic; }
        }

        private void MyFeatureDataForm_EditEnded(object sender, EventArgs e)
        {
            FeatureDataFormBorder.Visibility = System.Windows.Visibility.Collapsed;

        }

        private void EditorWidget_Loaded(object sender, RoutedEventArgs e)
        {

            EditorWidget editor = sender as EditorWidget;
          
        }

     
         
    }
}
